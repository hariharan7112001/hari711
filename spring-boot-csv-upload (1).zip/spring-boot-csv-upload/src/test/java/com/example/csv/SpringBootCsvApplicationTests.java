package com.example.csv;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringBootCsvApplicationTests {

	@Test
	void contextLoads() {
	}

}

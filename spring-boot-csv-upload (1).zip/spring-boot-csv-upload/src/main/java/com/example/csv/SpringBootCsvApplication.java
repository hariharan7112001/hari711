package com.example.csv;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;


@SpringBootApplication
public class SpringBootCsvApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringBootCsvApplication.class, args);
	}

}

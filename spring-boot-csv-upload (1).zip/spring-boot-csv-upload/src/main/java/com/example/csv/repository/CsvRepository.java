package com.example.csv.repository;

import com.example.csv.model.CSVModel;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface CsvRepository extends JpaRepository<CSVModel, Integer>{

}

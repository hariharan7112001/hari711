package com.example.csv.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import org.apache.commons.codec.binary.Base64;


@Entity
@Table(name = "csv_table")
public class CSVModel {

	  @Id
	  @Column(name = "id")
	  private long id;

	  @Column(name = "name")
	  private String name;

	  @Column(name = "role")
	  private String role;

	  @Column(name = "password")
	  private String password;

	  public CSVModel() {

	  }

	  public CSVModel(long id, String name, String role, String password) {
	    this.id = id;
	    this.name = name;
	    this.role = role;
	    this.password = password;
	  }

	  public long getId() {
	    return id;
	  }

	  public void setId(long id) {
	    this.id = id;
	  }

	  public String getName() {
	    return name;
	  }

	  public void setName(String name) {
	    this.name = name;
	  }

	  public String getRole() {
	    return role;
	  }

	  public void setRole(String role) {
	    this.role = role;
	  }

	public void setPassword(String password) {
		this.password = new String(Base64.encodeBase64(password.getBytes()));
	  }

	public String getPassword() {
		return new String(Base64.decodeBase64(password.getBytes()));
	}

	  @Override
	  public String toString() {
	    return "Csv [id=" + id + ", name=" + name + ", role=" + role + ", password=" + password + "]";
	  }
	}
